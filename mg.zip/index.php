<?php
// Silence is Golden.